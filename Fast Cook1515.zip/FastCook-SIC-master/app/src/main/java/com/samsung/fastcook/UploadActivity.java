package com.samsung.fastcook;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadActivity extends AppCompatActivity {
    ImageView uploadImage;
    Button saveButton, addIngredientsButton;
    Button removeIngredientsButton;
    EditText uploadName, uploadDesc;
    String imageURL;
    Uri uri;
    List<EditText> ingredientsEditTextList = new ArrayList<>();
    Spinner categorySpinner;

    private String[] categories = {"Breakfast", "Salad", "Sandwich", "Soup", "Pasta", "Pizza"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        uploadImage = findViewById(R.id.uploadImage);
        uploadDesc = findViewById(R.id.uploadDesc);
        uploadName = findViewById(R.id.uploadName);
        removeIngredientsButton = findViewById(R.id.removeIngredientsButton);

        saveButton = findViewById(R.id.saveButton);
        addIngredientsButton = findViewById(R.id.addIngredientsButton);
        categorySpinner = findViewById(R.id.categorySpinner);


        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            Intent data = result.getData();
                            uri = data.getData();
                            uploadImage.setImageURI(uri);
                        } else {
                            Toast.makeText(UploadActivity.this, "No Image Selected", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent photoPicker = new Intent(Intent.ACTION_PICK);
                photoPicker.setType("image/*");
                activityResultLauncher.launch(photoPicker);
            }
        });


        addIngredientsEditText();

        addIngredientsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addIngredientsEditText();
            }
        });
        removeIngredientsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeLastIngredientEditText();
            }
        });
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(spinnerAdapter);
    }

    private void addIngredientsEditText() {
        EditText ingredientEditText = new EditText(this);
        ingredientEditText.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        ingredientEditText.setHint("Enter Ingredients");
        LinearLayout layout = findViewById(R.id.uploadLayout);
        layout.addView(ingredientEditText);
        ingredientsEditTextList.add(ingredientEditText);
    }

    public void saveData() {
        String name = uploadName.getText().toString();
        String desc = uploadDesc.getText().toString();
        String selectedCategory = categorySpinner.getSelectedItem().toString();

        if (name.isEmpty() || desc.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (uri == null) {
            Toast.makeText(this, "Please select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Images").child(name);
        storageReference.putFile(uri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                imageURL = uri.toString();
                                uploadDataToFirebase(name, desc, selectedCategory);
                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(UploadActivity.this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void uploadDataToFirebase(String name, String desc, String category) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Dishes");

        String dishKey = reference.push().getKey();

        Map<String, Object> recipeData = new HashMap<>();
        recipeData.put("name", name);
        recipeData.put("desc", desc);
        recipeData.put("imageURL", imageURL);
        recipeData.put("category", category);
        recipeData.put("ingredients", getIngredientsList());

        reference.child("")
                .child(name)
                .setValue(recipeData)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(UploadActivity.this, "Recipe uploaded successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(UploadActivity.this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private List<String> getIngredientsList() {
        List<String> ingredients = new ArrayList<>();
        for (EditText editText : ingredientsEditTextList) {
            String ingredient = editText.getText().toString().trim();
            if (!ingredient.isEmpty()) {
                ingredients.add(ingredient);
            }
        }
        return ingredients;
    }
    private void removeLastIngredientEditText() {
        int lastIndex = ingredientsEditTextList.size() - 1;
        if (lastIndex >= 0) {
            EditText lastIngredientEditText = ingredientsEditTextList.get(lastIndex);
            LinearLayout layout = findViewById(R.id.uploadLayout);
            layout.removeView(lastIngredientEditText);
            ingredientsEditTextList.remove(lastIngredientEditText);
        }
    }
}

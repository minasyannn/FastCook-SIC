package com.samsung.fastcook;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Activity2 extends AppCompatActivity implements MyAdapter.OnItemClickListener {

    BottomNavigationView bottomNavigationView;
    FloatingActionButton fab;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;
    RecyclerView recyclerView;
    List<DataClass> dataList;
    List<DataClass> filteredList; // New variable
    MyAdapter adapter;

    private ImageView searchIcon;
    private View categories;
    private SearchView searchView;
    private TextView fastCookTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);

        recyclerView = findViewById(R.id.recyclerView);


        ImageView breakfast = findViewById(R.id.breakfast);

        searchIcon = findViewById(R.id.searchIcon);
        searchView = findViewById(R.id.searchView);
        categories = findViewById(R.id.categories);
        fastCookTextView = findViewById(R.id.FastCook_textview);
        searchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                searchIcon.setVisibility(View.GONE);
                categories.setVisibility(View.GONE);
                fastCookTextView.setVisibility(View.GONE);


                searchView.setVisibility(View.VISIBLE);
                searchView.setIconified(false);


                searchView.clearFocus();


                recyclerView.setVisibility(View.VISIBLE);
            }
        });

        breakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Activity2.this, CategoryActivity.class);
                intent1.putExtra("category", "breakfast");
                startActivity(intent1);
            }
        });

        breakfast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Activity2.this, CategoryActivity.class);
                intent1.putExtra("category", "breakfast");
                startActivity(intent1);
            }
        });

        ImageView salad = findViewById(R.id.salad);
        salad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Activity2.this, CategoryActivity.class);
                intent2.putExtra("category", "Salad");
                startActivity(intent2);
            }
        });

        ImageView sandwich = findViewById(R.id.sandwich);
        sandwich.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(Activity2.this, CategoryActivity.class);
                intent3.putExtra("category", "Sandwich");
                startActivity(intent3);
            }
        });

        ImageView soup = findViewById(R.id.soup);
        soup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent4 = new Intent(Activity2.this, CategoryActivity.class);
                intent4.putExtra("category", "Soup");
                startActivity(intent4);
            }
        });

        ImageView pasta = findViewById(R.id.pasta);
        pasta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent5 = new Intent(Activity2.this, CategoryActivity.class);
                intent5.putExtra("category", "Pasta");
                startActivity(intent5);
            }
        });

        ImageView pizza = findViewById(R.id.pizza);
        pizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent6 = new Intent(Activity2.this, CategoryActivity.class);
                intent6.putExtra("category", "Pizza");
                startActivity(intent6);
            }
        });



        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_item1:
                    Intent intent1 = new Intent(this, Activity2.class);
                    startActivity(intent1);
                    return true;
                case R.id.navigation_item3:
                    Intent intent3 = new Intent(this, UserActivity.class);
                    startActivity(intent3);
                    return true;
                case R.id.navigation_item4:
                    Intent intent4 = new Intent(this, UploadActivity.class);
                    startActivity(intent4);
                    return true;
                default:
                    return false;
            }
        });

        GridLayoutManager gridLayoutManager = new GridLayoutManager(Activity2.this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(8), true));

        AlertDialog.Builder builder = new AlertDialog.Builder(Activity2.this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress_layout);
        AlertDialog dialog = builder.create();
        dialog.show();

        dataList = new ArrayList<>();
        filteredList = new ArrayList<>(); // Initialize filteredList

        adapter = new MyAdapter(Activity2.this, filteredList); // Use filteredList in the adapter
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(this);

        databaseReference = FirebaseDatabase.getInstance().getReference("Dishes");
        dialog.show();
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataList.clear();
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    DataClass dataClass = itemSnapshot.getValue(DataClass.class);

                    dataClass.setKey(itemSnapshot.getKey());

                    dataList.add(dataClass);
                }
                filter("");
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });
    }

    @Override
    public void onItemClick(int position) {
        DataClass selectedItem = filteredList.get(position);
        Intent intent = new Intent(Activity2.this, DetailActivity.class);
        intent.putExtra("name", selectedItem.getName());
        intent.putExtra("desc", selectedItem.getDesc());
        intent.putExtra("category", selectedItem.getCategory());
        intent.putStringArrayListExtra("ingredients", (ArrayList<String>) selectedItem.getIngredients());
        intent.putExtra("imageURL", selectedItem.getImageURL());
        startActivity(intent);
    }


    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {
        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount;

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount;
                outRect.right = (column + 1) * spacing / spanCount;

                if (position < spanCount) {
                    outRect.top = spacing;
                }
                outRect.bottom = spacing;
            } else {
                outRect.left = column * spacing / spanCount;
                outRect.right = spacing - (column + 1) * spacing / spanCount;
                if (position >= spanCount) {
                    outRect.top = spacing;
                }
            }
        }
    }

    // Method to filter the data based on the search query
    private void filter(String query) {
        filteredList.clear();
        for (DataClass item : dataList) {
            if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.notifyDataSetChanged();
    }
}

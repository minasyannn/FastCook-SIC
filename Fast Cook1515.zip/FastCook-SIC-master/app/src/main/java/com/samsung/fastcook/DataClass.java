package com.samsung.fastcook;

import java.util.List;

public class DataClass {
    private String Name;
    private String desc;
    private String lang;
    private String imageURL;
    private String key;
    private String category;
    private List<String> ingredients;

    public DataClass() {

    }

    public DataClass(String Name, String desc, String lang, String imageURL, String key, String category) {
        this.Name = Name;
        this.desc = desc;
        this.lang = lang;
        this.imageURL = imageURL;
        this.key = key;
        this.category = category;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }
}

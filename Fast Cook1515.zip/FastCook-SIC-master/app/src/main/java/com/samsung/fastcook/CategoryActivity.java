package com.samsung.fastcook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CategoryActivity extends AppCompatActivity implements MyAdapter.OnItemClickListener {

    private List<DataClass> dataList;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        Intent intent = getIntent();
        String category = intent.getStringExtra("category");

        TextView categoryNameTextView = findViewById(R.id.category_name);
        categoryNameTextView.setText(category);
        categoryNameTextView.setVisibility(View.VISIBLE);

        if (category != null) {
            loadDishesFromCategory(category);
            Button backButton = findViewById(R.id.backtoactivity2);
            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(CategoryActivity.this, Activity2.class);
                    startActivity(intent);
                }
            });
        }
    }

    private void loadDishesFromCategory(String category) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference dishesRef = database.getReference("Dishes");

        dishesRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                dataList = new ArrayList<>();

                for (DataSnapshot dishSnapshot : dataSnapshot.getChildren()) {
                    DataClass dataClass = dishSnapshot.getValue(DataClass.class);

                    if (dataClass != null && dataClass.getCategory().equalsIgnoreCase(category)) {
                        dataList.add(dataClass);
                    }
                }

                if (dataList.isEmpty()) {
                    Toast.makeText(CategoryActivity.this, "No dishes found in the selected category.", Toast.LENGTH_SHORT).show();
                } else {
                    setupRecyclerView();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(CategoryActivity.this, "Failed to load dishes from the database.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myAdapter = new MyAdapter(this, dataList);
        recyclerView.setAdapter(myAdapter);

        myAdapter.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(int position) {
        DataClass data = dataList.get(position);
        // Handle item click event
        Intent intent = new Intent(CategoryActivity.this, DetailActivity.class);
        intent.putExtra("name", data.getName());
        intent.putExtra("desc", data.getDesc());
        intent.putExtra("category", data.getCategory());
        intent.putStringArrayListExtra("ingredients", (ArrayList<String>) data.getIngredients());
        intent.putExtra("imageURL", data.getImageURL());
        startActivity(intent);
    }
}


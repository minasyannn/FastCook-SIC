package com.samsung.fastcook;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.samsung.fastcook.LoginActivity;

public class OnboardingFragment extends Fragment {
    private static final String ARG_LAYOUT_RES_ID = "layoutResId";

    private int layoutResId;

    public static OnboardingFragment newInstance(int layoutResId) {
        OnboardingFragment fragment = new OnboardingFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_LAYOUT_RES_ID, layoutResId);
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            layoutResId = getArguments().getInt(ARG_LAYOUT_RES_ID);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView;

        if (layoutResId == R.layout.onboarding_page_1) {
            rootView = inflater.inflate(R.layout.onboarding_page_1, container, false);

            Button buttonNext = rootView.findViewById(R.id.button_next);
            buttonNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ViewPager viewPager = getActivity().findViewById(R.id.viewPager);
                    viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                }
            });
        } else if (layoutResId == R.layout.onboarding_page_2) {
            rootView = inflater.inflate(R.layout.onboarding_page_2, container, false);

            Button buttonNext = rootView.findViewById(R.id.button_next);
            buttonNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ViewPager viewPager = getActivity().findViewById(R.id.viewPager);
                    viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                }
            });
        } else if (layoutResId == R.layout.onboarding_page_3) {
            rootView = inflater.inflate(R.layout.onboarding_page_3, container, false);

            Button buttonFinish = rootView.findViewById(R.id.button_finish);
            buttonFinish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    startActivity(intent);

                    getActivity().finish();
                }
            });
        } else {

            rootView = inflater.inflate(layoutResId, container, false);
        }

        return rootView;
    }
}


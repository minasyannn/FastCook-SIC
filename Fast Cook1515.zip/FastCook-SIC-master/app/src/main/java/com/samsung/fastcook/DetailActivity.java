package com.samsung.fastcook;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {
    private RecyclerView dishIngredients;
    private IngredientsAdapter ingredientsAdapter;
    ImageView dishImage;
    TextView dishName, dishDesc, dishCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        dishImage = findViewById(R.id.detailImage);
        dishName = findViewById(R.id.detailName);
        dishDesc = findViewById(R.id.detailDesc);
        dishCategory = findViewById(R.id.detailCategory);
        dishIngredients = findViewById(R.id.ingredientsRecyclerView);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String name = extras.getString("name");
            String desc = extras.getString("desc");
            String category = extras.getString("category");
            ArrayList<String> ingredients = extras.getStringArrayList("ingredients");
            String imageURL = extras.getString("imageURL");


            dishName.setText(name);
            dishDesc.setText(desc);
            dishCategory.setText(category);

            ingredientsAdapter = new IngredientsAdapter(ingredients);
            dishIngredients.setAdapter(ingredientsAdapter);
            dishIngredients.setLayoutManager(new LinearLayoutManager(this));

            Glide.with(this).load(imageURL).into(dishImage);
        }

        Button backButton = findViewById(R.id.back_to_SearchActivity);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailActivity.this, Activity2.class);
                startActivity(intent);
            }
        });
    }
}

package com.samsung.fastcook;

import java.util.List;

public class Dish {
    private String name;
    private String category;
    private String description;
    private String imageURL;
    private List<String> ingredients;

    public Dish(String name, String category, String description, String imageURL, List<String> ingredients) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.imageURL = imageURL;
        this.ingredients = ingredients;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public String getImageURL() {
        return imageURL;
    }

    public List<String> getIngredients() {
        return ingredients;
    }
}
